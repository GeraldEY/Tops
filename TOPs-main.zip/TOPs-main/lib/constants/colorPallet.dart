import 'package:flutter/material.dart';

class ColorPallet {
  static Color whiteBasic = Color(0xFFFFFFFF);
  static Color lightGrey = Color(0xFFEEEAEA);
  static Color greenPrimary = Color.fromARGB(255, 33, 153, 37);
}
