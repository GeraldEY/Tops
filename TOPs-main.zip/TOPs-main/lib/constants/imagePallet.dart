const mainLogo = "assets/images/main_logo.png";
const logo = "assets/images/Logo.png";
const google = "assets/images/google.png";
const trash = "assets/images/trash.png";

const arrival0 = 'assets/images/arrival0.png';
const arrival1 = 'assets/images/arrival1.png';
const arrival2 = 'assets/images/arrival2.png';
const arrival3 = 'assets/images/arrival3.png';
const arrival4 = 'assets/images/arrival4.png';

const sliderTop0 = 'assets/images/slider0.png';
const sliderTop1 = 'assets/images/slider1.png';
const sliderTop2 = 'assets/images/slider2.png';
const sliderTop3 = 'assets/images/slider3.png';

const brand0 = 'assets/images/brand0.png';
const brand1 = 'assets/images/brand1.png';
const brand2 = 'assets/images/brand2.png';
const brand3 = 'assets/images/brand3.png';
const brand4 = 'assets/images/brand4.png';

const best0 = 'assets/images/best0.png';
const best1 = 'assets/images/best1.png';
const best2 = 'assets/images/best2.png';
const best3 = 'assets/images/best3.png';
const best4 = 'assets/images/best4.png';
